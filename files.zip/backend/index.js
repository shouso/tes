const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const bodyParser = require("body-parser");
const { v4: uuidv4 } = require("uuid");
const { sequelize, QueueEntry } = require("./models");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(bodyParser.json());

async function broadcastQueue(location = "default") {
  const queue = await QueueEntry.findAll({ where: { location }, order: [["createdAt", "ASC"]] });
  io.to(location).emit("queue:update", queue);
}

app.get("/queue", async (req, res) => {
  const location = req.query.location || "default";
  const queue = await QueueEntry.findAll({ where: { location }, order: [["createdAt", "ASC"]] });
  res.json(queue);
});

app.post("/queue/join", async (req, res) => {
  const { name, location = "default" } = req.body;
  if (!name) return res.status(400).json({ error: "Name required" });
  const entry = await QueueEntry.create({
    id: uuidv4(),
    name: name.trim(),
    location,
    createdAt: new Date(),
  });
  await broadcastQueue(location);
  res.status(201).json(entry);
});

app.post("/queue/leave", async (req, res) => {
  const { id, location = "default" } = req.body;
  const entry = await QueueEntry.findOne({ where: { id, location } });
  if (!entry) return res.status(404).json({ error: "Not found" });
  await entry.destroy();
  await broadcastQueue(location);
  res.json({ ok: true });
});

app.post("/queue/next", async (req, res) => {
  const location = req.body.location || "default";
  const queue = await QueueEntry.findAll({ where: { location }, order: [["createdAt", "ASC"]] });
  if (queue.length === 0) return res.status(400).json({ error: "Queue empty" });
  const next = queue[0];
  await next.destroy();
  await broadcastQueue(location);
  res.json(next);
});

app.get("/queue/join-link", (req, res) => {
  const location = req.query.location || "default";
  res.json({ url: `http://localhost:3000/?queue=${location}` });
});

io.on("connection", (socket) => {
  socket.on("subscribe-location", async (location = "default") => {
    socket.join(location);
    const queue = await QueueEntry.findAll({ where: { location }, order: [["createdAt", "ASC"]] });
    socket.emit("queue:update", queue);
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, async () => {
  await sequelize.authenticate();
  await sequelize.sync();
  console.log(`Queue backend running on http://localhost:${PORT}`);
});