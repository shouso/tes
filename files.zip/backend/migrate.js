const { sequelize, QueueEntry } = require('./models');

async function migrate() {
  await sequelize.sync({ force: true });
  console.log("Migration complete: SQLite DB created with QueueEntry table.");
}

migrate().catch(err => {
  console.error(err);
  process.exit(1);
});