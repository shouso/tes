const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './queue.sqlite',
});

const QueueEntry = sequelize.define('QueueEntry', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  name: DataTypes.STRING,
  location: {
    type: DataTypes.STRING,
    defaultValue: 'default',
    index: true,
  },
  createdAt: DataTypes.DATE,
});

module.exports = { sequelize, QueueEntry };