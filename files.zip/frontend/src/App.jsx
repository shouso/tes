import React from "react";
import QueueApp from "./QueueApp";

export default function App() {
  return <QueueApp />;
}