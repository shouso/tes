import React, { useEffect, useState } from 'react';
import io from "socket.io-client";
import QRCode from "qrcode.react";

const SOCKET_URL = process.env.REACT_APP_API_BASE || 'http://localhost:4000';

function useQueueParam() {
  const [location, setLocation] = useState('default');
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setLocation(params.get('queue') || 'default');
  }, []);
  return location;
}

export default function KioskDisplay() {
  const [queue, setQueue] = useState([]);
  const location = useQueueParam();
  useEffect(() => {
    const socket = io(SOCKET_URL);
    socket.emit("subscribe-location", location);
    socket.on("queue:update", setQueue);
    return () => socket.disconnect();
  }, [location]);

  const nowServing = queue[0] ? queue[0].name : 'N/A';
  const nextInLine = queue.slice(1, 6);
  const joinUrl = `${window.location.origin}/?queue=${encodeURIComponent(location)}`;
  return (
    <div style={{ background: "#f7f7fb", height: "100vh", display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div style={{
        marginTop: 40, background: "white", borderRadius: "16px",
        padding: "40px 60px", boxShadow: "0 16px 32px rgba(0,0,0,0.07)", minWidth: 400
      }}>
        <h1 style={{ fontSize: "3rem", marginBottom: 32 }}>Now Serving</h1>
        <div style={{ fontSize: "2.8rem", color: "#0b5fff", fontWeight: 700, marginBottom: 16 }}>
          {nowServing}
        </div>
        <div style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: "1.5rem", marginBottom: 8 }}>Next in Line</h2>
          <ol style={{ fontSize: "1.25rem", color: "#444" }}>
            {nextInLine.length === 0 ? <li>Waiting...</li> :
              nextInLine.map(entry => <li key={entry.id}>{entry.name}</li>)
            }
          </ol>
        </div>
        <div style={{ textAlign: "center", marginTop: 32 }}>
          <h3>Scan to Join Queue: <span>{location}</span></h3>
          <QRCode value={joinUrl} size={128} />
          <p style={{ color: "#777", fontSize: 16, marginTop: 12 }}>
            Open camera on your phone<br />or scan with a QR app.
          </p>
        </div>
      </div>
    </div>
  );
}