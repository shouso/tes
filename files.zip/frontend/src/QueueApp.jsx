import React, { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';
import { fetchQueue, joinQueue, leaveQueue, callNext } from './api';

const SOCKET_URL = process.env.REACT_APP_API_BASE || 'http://localhost:4000';

function useQueueParam() {
  const [location, setLocation] = useState('default');
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setLocation(params.get('queue') || 'default');
  }, []);
  return location;
}

export default function QueueApp() {
  const [queue, setQueue] = useState([]);
  const [name, setName] = useState('');
  const [myId, setMyId] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const location = useQueueParam();
  const socketRef = useRef(null);

  useEffect(() => {
    fetchQueue(location).then(setQueue);
    const socket = io(SOCKET_URL);
    socket.emit("subscribe-location", location);
    socket.on("queue:update", setQueue);
    socketRef.current = socket;
    return () => socket.disconnect();
  }, [location]);

  const handleJoin = async () => {
    if (!name.trim()) return;
    try {
      const entry = await joinQueue(name.trim(), location);
      setMyId(entry.id);
      setName('');
    } catch (e) { alert('Failed to join'); }
  };
  const handleLeave = async () => {
    if (!myId) return;
    try {
      await leaveQueue(myId, location);
      setMyId(null);
    } catch (e) { alert('Failed to leave'); }
  };

  const handleCallNext = async () => {
    try {
      const served = await callNext(location);
      alert(`Called next: ${served.name}`);
    } catch (e) { alert('No one to call'); }
  };

  const myPosition = myId ? queue.findIndex(entry => entry.id === myId) + 1 : null;

  return (
    <div className="container">
      <h2>Public Space Queue – <span>{location}</span></h2>
      {!myId ? (
        <div>
          <input value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Your name"
            style={{ padding: 8, marginRight: 8 }}
          />
          <button onClick={handleJoin} style={{ padding: '8px 12px' }}>
            Join Queue
          </button>
        </div>
      ) : (
        <div>
          <p>
            You are in queue. Position: <strong>{myPosition}</strong>
            {myPosition === 1 && <span> — You are next!</span>}
          </p>
          <button onClick={handleLeave} style={{ padding: '8px 12px' }}>
            Leave Queue
          </button>
        </div>
      )}

      <div className="admin-controls" style={{ marginTop: 16 }}>
        <label style={{ marginRight: 8 }}>
          <input type="checkbox" checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} /> Admin
        </label>
        {isAdmin && (
          <button onClick={handleCallNext} style={{ marginLeft: 8, padding: '8px 12px' }}>
            Call Next
          </button>
        )}
      </div>

      <h3 style={{ marginTop: 20 }}>Current Queue ({queue.length}):</h3>
      <ol className="queue-list">
        {queue.map((entry, idx) => (
          <li
            key={entry.id}
            className={`queue-item ${entry.id === myId ? 'you' : ''}`}
            style={{ padding: '6px 0' }}
          >
            {idx + 1}. {entry.name} {entry.id === myId ? ' (You)' : ''}
          </li>
        ))}
      </ol>
    </div>
  );
}