const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:4000';

export async function fetchQueue(location = "default") {
  const res = await fetch(`${API_BASE}/queue?location=${location}`);
  return res.json();
}

export async function joinQueue(name, location = "default") {
  const res = await fetch(`${API_BASE}/queue/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, location })
  });
  if (!res.ok) throw new Error('join failed');
  return res.json();
}

export async function leaveQueue(id, location = "default") {
  const res = await fetch(`${API_BASE}/queue/leave`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, location })
  });
  if (!res.ok) throw new Error('leave failed');
  return res.json();
}

export async function callNext(location = "default") {
  const res = await fetch(`${API_BASE}/queue/next`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ location }),
  });
  if (!res.ok) throw new Error('next failed');
  return res.json();
}